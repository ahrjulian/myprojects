SELECT count(distinct(title)) FROM episodes; 
