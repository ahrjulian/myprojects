import cs50
import sys

class Pet():
    def __init__(self, name, species):
        self.name = name
        self.species = species


dog = Pet("Paul", "Hund")

name = dog.name
species = dog.species

print(f"Name: {name}, Species: {species}")
