SELECT id, title, production_code FROM episodes ORDER BY production_code ASC; 
