SELECT title FROM episodes WHERE season = "6" AND air_date LIKE "2007%"; 
