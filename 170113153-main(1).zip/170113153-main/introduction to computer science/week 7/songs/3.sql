SELECT name FROM songs Order by duration_ms DESC LIMIT 5;

