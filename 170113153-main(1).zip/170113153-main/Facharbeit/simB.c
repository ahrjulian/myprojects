#define _DEFAULT_SOURCE
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>
#include <cs50.h>

//main simulation für die average number of children
typedef struct
{
    char chromosome0;
    char chromosome1;
}person;

const int generations = 2;
char H,X,Y;
int Anzahl_personen = 0; //Anzahl personen by default
person gen[generations][20]; //max 20 Kinder pro familie
int Anzahl_erkrankte_Maenner = 0;
int Anzahl_erkrankte_Frauen = 0;
int Anzahl_träger_Frauen = 0;

int main (void)
{
    srandom(time(0));
    //base case
    gen[0][0].chromosome0 = 'X';
    gen[0][0].chromosome1 = 'Y';

    gen[0][1].chromosome0 = 'X';
    gen[0][1].chromosome1 = 'H';

    int Anzahl_Kinder_pro_Familie = 6; //Anzahl an Kindern pro Familie

    for(int i = 1; i < generations; i++)
    {
        for (int j = 0; j < Anzahl_Kinder_pro_Familie; j++)
        {
            if (j & 1)
            {
                //ungerade (Frau)
                int random_number = random() % 2;
                if (random_number == 0)
                {
                    gen[i][j].chromosome0 = gen[i - 1][1].chromosome0;
                }
                else
                {
                    gen[i][j].chromosome0 = gen[i - 1][1].chromosome1;
                }
                gen[i][j].chromosome1 = gen[i - 1][0].chromosome0;
            }
            else
            {
                //gerade (Mann)
                int random_number_2 = random() % 2;
                if (random_number_2 == 0)
                {
                    gen[i][j].chromosome0 = gen[i - 1][1].chromosome0;
                }
                else
                {
                    gen[i][j].chromosome0 = gen[i - 1][1].chromosome1;
                }
                gen[i][j].chromosome1 = 'Y';
            }
        }
    }
    for (int i = 0; i < generations; i++)
    {
        for (int j = 0; j < Anzahl_Kinder_pro_Familie; j++)
        {
            if (gen[i][j].chromosome0 == 'H' && gen[i][j].chromosome1 == 'Y')
            {
                Anzahl_erkrankte_Maenner++;
            }
            if (gen[i][j].chromosome0 == 'H' && gen[i][j].chromosome1 == 'H')
            {
                Anzahl_erkrankte_Frauen++;
            }
            if ((gen[i][j].chromosome0 == 'H' || gen[i][j].chromosome1 == 'H') && (gen[i][j].chromosome0 == 'X' || gen[i][j].chromosome1 == 'X'))
            {
                Anzahl_träger_Frauen++;
            }
            //Anzahl_personen++;
        }
    }
    printf("Anzahl erkrankte Männer: %d\n", Anzahl_erkrankte_Maenner);
    printf("Anzahl träger Frauen: %d\n", Anzahl_träger_Frauen);
    printf("Anzahl erkrankte Frauen: %d\n", Anzahl_erkrankte_Frauen);
    //printf("Anzahl Personen: %d\n", Anzahl_personen);
}
