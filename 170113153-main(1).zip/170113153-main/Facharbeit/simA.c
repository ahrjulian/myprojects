#define _DEFAULT_SOURCE
#include <stdbool.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdio.h>

//Hämopholie: Die Erkrankung wird in der Regel X-chromosomal-ressesiv vererbt. Männer, die das fehlende Gen von ihrer Mutter erben,
//erkranken an der Blutgerinnungsstörung.Frauen hingegen können den Gendefekt in der Regel durch ihr zweites, gesundes X-Chromosom ausgliechen
const int number_children_per_family = 2;
//Komma Zahlen sind nicht möglich
typedef struct person
{
    struct person *parents[2];
    struct person *children[2];//parents sind jeweils eine eigene person(must have const size)
    //struct person *partner[1];
    char Chromosoms[2];
    char Gender;
}person;

int Anzahl_erkrankte_männer = 0;
int Anzahl_träger_frauen = 0;
int Anzahl_erkrankte_frauen = 0;


person *create_family(int generations);
person *create_partner(char Gender_partner);
char random_chromosome();
void free_family(person *p);
void print_data();
char random_chromosome_partner_erkrankt();


const int MAX_GENERATIONS_TO_BE_SIMULATED = 2;
int Anzahl_personen = 0;
char H, X, Y;
char M, W;

int main (void)
{
    srandom(time(0));

    person *p = create_family(MAX_GENERATIONS_TO_BE_SIMULATED);
    if (p == NULL)
    {
        return 1;
    }

    print_data();

    free_family(p);
}

person* create_family (int generations)
{

    person* new_person = malloc(sizeof(person));

    Anzahl_personen = Anzahl_personen + 1;

    if (generations > 1)
    {
        person *parent0 = create_family(generations - 1);
        char Gender = (parent0 -> Gender == 'M') ? 'W' : 'M';

        person *parent1 = create_partner(Gender == 'M' ? 'W' : 'M');


        new_person -> parents[0] = parent0;
        new_person -> parents[1] = parent1;

        new_person -> Chromosoms[0] = parent0 -> Chromosoms[random() % 2];
        new_person -> Chromosoms[1] = parent1 -> Chromosoms[random() % 2];

        if ((new_person -> Chromosoms[0] == 'H' || new_person -> Chromosoms[1] == 'H') && (new_person -> Gender == 'M'))
        {
            Anzahl_erkrankte_männer = Anzahl_erkrankte_männer + 1;
        }
        else if (new_person -> Chromosoms[0] == 'H' && new_person -> Chromosoms[1] == 'H')
        {
            Anzahl_erkrankte_frauen = Anzahl_erkrankte_frauen + 1;
        }
        else if ((new_person -> Chromosoms[0] == 'H' || new_person -> Chromosoms[1] == 'H') && (new_person -> Chromosoms[0] == 'X' || new_person -> Chromosoms[1] == 'X'))
        {
            Anzahl_träger_frauen = Anzahl_träger_frauen + 1;
        }

        for (int i = 0; i < number_children_per_family; i++)
        {
            new_person -> children[i] = create_family(generations - 1);

        }
        return new_person;
    }

    else//erste Generation
    {
        new_person -> parents[0] = NULL;
        new_person -> parents[1] = NULL;

        new_person -> Chromosoms[0] = 'X';
        new_person -> Chromosoms[1] = 'Y';


        new_person -> Gender = 'M';

        for (int i = 0; i < number_children_per_family; i++)
        {
            new_person -> children[i] = create_family(generations - 1);
        }
    }
    return new_person;
}

person *create_partner(char Gender_partner)
{
    person *new_partner = malloc(sizeof(person));

    Anzahl_personen = Anzahl_personen + 1;

    new_partner -> parents[0] = NULL;
    new_partner -> parents[1] = NULL;

    new_partner -> Gender = Gender_partner;

    if (new_partner -> Gender == 'M')
    {
        new_partner -> Chromosoms[0] = random_chromosome_partner_erkrankt();
        if (new_partner -> Chromosoms[0] == 'H')
        {
            Anzahl_erkrankte_männer = Anzahl_erkrankte_männer + 1;
        }
        new_partner -> Chromosoms[1] = 'Y';

    }
    else if (new_partner -> Gender == 'W')
    {
        new_partner -> Chromosoms[0] = random_chromosome_partner_erkrankt();
        new_partner -> Chromosoms[1] = random_chromosome_partner_erkrankt();

        if ((new_partner -> Chromosoms[0] == 'H' || new_partner -> Chromosoms[1] == 'H') && (new_partner -> Chromosoms[0] == 'X' || new_partner -> Chromosoms[1] == 'X'))
        {
            Anzahl_träger_frauen = Anzahl_träger_frauen + 1;
        }
        else if (new_partner -> Chromosoms[0] == 'H' && new_partner -> Chromosoms[1] == 'H')
        {
            Anzahl_erkrankte_frauen = Anzahl_erkrankte_frauen + 1;
        }

    }
    return new_partner;

}

char random_chromosome()
{
    int random_number = random() % 2;
    if (random_number == 0)
    {
        int hemophilie_chromosome = random() % 5000;
        if (hemophilie_chromosome == 1)
        {
            return 'H';
        }
        else
        {
            return 'X';
        }
    }
    else if (random_number == 1)
    {
        return 'Y';
    }
    return 'X';
}
char random_chromosome_partner_erkrankt()
{
    int hemophilie_chromosome = random() % 5000;
    if (hemophilie_chromosome == 1)
    {
        return 'H';
    }
    else
    {
        return 'X';
    }
    return 'X';
}

void print_data()
{
    printf("Anzahl erkrankte Männer: %d \n", Anzahl_erkrankte_männer);
    printf("Anzahl Träger: %d \n", Anzahl_träger_frauen);
    printf("Anzahl erkrankte Frauen: %d \n", Anzahl_erkrankte_frauen);
    //Prozentsatz pro Generation
}

void free_family(person *p)//free allocated memory
{
    if (p == NULL)
    {
        return;
    }


    for (int i = 0; i < number_children_per_family; i ++)
    {
        free_family(p -> children[i]);
    }


    free_family(p -> parents[1]);
    free_family(p -> parents[0]);

    free(p);
}


