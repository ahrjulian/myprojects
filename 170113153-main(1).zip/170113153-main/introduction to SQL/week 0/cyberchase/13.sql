SELECT title, id FROM episodes WHERE season = "2" OR season = "3"; 
