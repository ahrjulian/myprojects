SELECT Join()
SELECT AVG(energy) FROM songs WHERE artist_id = '23' DESC;
