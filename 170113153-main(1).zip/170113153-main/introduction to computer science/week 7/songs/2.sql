SELECT name FROM songs
Order by tempo;
