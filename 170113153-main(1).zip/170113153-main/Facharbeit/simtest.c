#define _DEFAULT_SOURCE
#include <string.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
FILE *csv_file;

//loops trough x number of years
//-> 1:5000
const int GENERATIONS = 4;

//functions:
person *create_person(GENERATIONS);

typedef struct person
{
    struct person *parents[2];
    struct person *siblings[2];
    char ch[2];
    char Gender;
}person;

void open_csv_file()//open csv file to store data
{
    csv_file = fopen("hemophilie.csv", "w");
    if (csv_file == NULL)
    {
        exit(1);
    }
    fprintf(csv_file, "Population size, Affected\n");
}

int main (void)
{
    open_csv_file();

    srandom(time(0));

    create_person(GENERATIONS);


}

person *create_person(int generations)
{
    person *new_person = malloc(sizeof(person));

    if (new_person == NULL)
    {
        free(person);
        return NULL;
    }

    

}




