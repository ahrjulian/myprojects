#define _DEFAULT_SOURCE
#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

typedef struct person
{
    struct person *parents[2];
    char chromosome[2];
    struct person *sibling[1];
    struct person* partner[1];
    char Gender;
}person;

char M,W,H,X,Y;
int personCount = 0;

void print_family();
void free_family(person *p);
person *create_family(int generations);
char random_chromosome();
person *create_partner(char partner_Gender);
const int GENERATIONS = 4;

int main (void)
{
    srandom(time(0));

    person *p = create_family(GENERATIONS);

    print_family();

    free_family(p);
}

person *create_family(int generations)
{
    person *new_person = malloc(sizeof(person));

    if (new_person == NULL)
    {
        free(new_person);
        return NULL;
    }

    if (generations > 1)
    {

        person *parent0 = create_family(generations - 1);
        if (parent0 == NULL)
        {
            free(parent0);
            free(new_person);
            return NULL;
        }

        new_person -> parents[0] = parent0;

        person *parent1 = create_family(generations - 1);

        new_person -> parents[1] = parent1 -> partner[0];

        //Chromosome spielen hier noch keine Rolle

        if (personCount % 2 == 0)
        {
            //gerade Zahl
            person *sibling0 = create_family(generations);
            new_person -> sibling[0] = sibling0;
        }
        else
        {
            new_person -> sibling[0] = NULL;
        }

        char partner_Gender;

        if (new_person -> Gender == 'M')
        {
            partner_Gender = 'W';
        }
        else
        {
            partner_Gender = 'M';
        }

        new_person -> partner[0] = create_partner(partner_Gender);

    }
    else
    {
        new_person -> parents[0] = NULL;
        new_person -> parents[1] = NULL;

        new_person -> chromosome[0] = 'Y';
        new_person -> chromosome[1] = random_chromosome();

        new_person -> Gender = 'M';

        char partner_Gender = 'W';

        new_person -> partner[0] = create_partner(partner_Gender);
    }
    personCount++;
    return new_person;
}

person *create_partner(char partner_Gender)
{
     person *new_partner = malloc(sizeof(person));

     new_partner -> parents[0] = NULL;
     new_partner -> parents[1] = NULL;

     //chromosome werden auch hier erstmal weg gelassen

     if (partner_Gender == 'W')
     {
        new_partner -> chromosome[0] = random_chromosome();
        new_partner -> chromosome[1] = random_chromosome();
     }
     else
     {
        new_partner -> chromosome[0] = 'Y';
        new_partner -> chromosome[1] = random_chromosome();
     }
     return new_partner;
}

char random_chromosome()
{
    int index = random() % 5;
    if (index == 1)
    {
        return 'H';
    }
    else
    {
        return 'X';
    }
    return 'X';
}

void print_family()
{
    printf("Anzahl an Personen %d \n ", personCount);
}

void free_family(person* p)
{
    if (p == NULL)
    {
        return;
    }

    free_family(p -> parents[0]);
    free_family(p -> parents[1]);

    free_family(p -> sibling[0]); 

    free(p);
}
